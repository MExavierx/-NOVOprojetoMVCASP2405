using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace aplicacaoMVC2405.Views.Home
{
    public class Index2Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
