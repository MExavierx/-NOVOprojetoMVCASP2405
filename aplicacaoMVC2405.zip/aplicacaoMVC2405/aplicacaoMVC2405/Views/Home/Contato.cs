﻿namespace aplicacaoMVC2405.Views.Home
{
    public class Contato
    {
    }
}
