using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace aplicacaoMVC2405.Views.Home
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
