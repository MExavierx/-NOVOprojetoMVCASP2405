using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace aplicacaoMVC2405.Views.Home
{
    public class ContatoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
